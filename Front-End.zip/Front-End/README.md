Section for front- end
Add names of active members
